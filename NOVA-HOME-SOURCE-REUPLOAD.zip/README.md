# NOVA Home v1.0.1 — Geometry Dash 2.2081

Redesigned Geode main menu: a large center Play tile, Creator and Garage on either side, soft glass surfaces, custom accent color, tile entrance animations, and smaller shortcut tiles.

## Fixes in v1.0.1
- **Fixed critical CMake configuration error:** `mod.json` now sets `"geode": "5.11.2"` to match the SDK version reported by Geode 5.11.2. Note that the action's SDK release tag can remain `v5.11.2`.
- **Added mandatory `geode.node-ids` dependency** (`>=v1.23.3`) and requests Node IDs prior to looking up the vanilla buttons.
- Updated scale clamp to avoid negative scales on unexpectedly small game windows.
- Added a preflight validation script to catch mismatched mod versions before expensive builds.

## Install/build

**No folders need to be added manually to the GitHub repository.** Upload/replace `nova-home-geode-source.zip` in the root of the repository, leave the existing `.github/workflows/build-nova-home.yml` in place, and use Actions → Build NOVA Home Geode Mod → Run workflow. Replacing the ZIP alone also triggers the workflow when committed.

Your existing workflow is compatible with this fixed source ZIP. A replacement workflow is also provided as an optional improvement, with preflight validation and clearer logging.

The build compiles the mod for Android32, Android64, and Win64, and the combine job merges their packages. For runtime behavior, enable/install the Node IDs dependency through the Geode mod loader.

## Validation limits

- Source ZIP integrity, JSON parsing/metadata, workflow syntax, and preflight checks are tested here.
- **Not compiled using the real Geode SDK in this environment.** Geode headers and toolchains are not locally available; a successful GitHub Actions build is required to confirm compilation and installation.
- `NOVA Home` targets GD 2.2081 and Geode 5.11.2 and may conflict with another mod that replaces the same UI. It leaves the original buttons in the scene and forwards clicks to their original callbacks.
