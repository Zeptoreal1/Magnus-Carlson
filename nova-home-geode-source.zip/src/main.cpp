#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>

#include <algorithm>
#include <array>
#include <cmath>
#include <string>
#include <unordered_set>
#include <vector>

using namespace geode::prelude;

namespace {

// A lightweight translucent rounded panel. No external textures or shader effects
// are needed, so it also runs on Android 32-bit devices.
void roundedRect(
    CCDrawNode* painter, float x, float y, float width, float height,
    float radius, ccColor4F fill, ccColor4F outline
) {
    constexpr int segments = 9;
    constexpr float pi = 3.14159265358979323846f;
    radius = std::min(radius, std::min(width, height) * .5f);
    std::vector<CCPoint> polygon;
    polygon.reserve(4 * (segments + 1));

    const std::array<CCPoint, 4> centers = {{
        ccp(x + width - radius, y + radius),
        ccp(x + width - radius, y + height - radius),
        ccp(x + radius, y + height - radius),
        ccp(x + radius, y + radius)
    }};
    for (int corner = 0; corner < 4; ++corner) {
        const float start = -pi * .5f + static_cast<float>(corner) * pi * .5f;
        for (int step = 0; step <= segments; ++step) {
            float angle = start + static_cast<float>(step) / segments * pi * .5f;
            polygon.push_back(ccp(
                centers[corner].x + std::cos(angle) * radius,
                centers[corner].y + std::sin(angle) * radius
            ));
        }
    }
    painter->drawSolidPoly(polygon.data(), static_cast<unsigned int>(polygon.size()), fill);
    painter->drawPoly(polygon.data(), static_cast<unsigned int>(polygon.size()), true, outline);
}

ccColor4F rgba(int r, int g, int b, float a) {
    return ccc4f(r / 255.f, g / 255.f, b / 255.f, a);
}

ccColor4F accent4(ccColor3B color, float a) {
    return ccc4f(color.r / 255.f, color.g / 255.f, color.b / 255.f, a);
}

CCMenuItem* findOriginal(CCNode* root, std::initializer_list<char const*> ids) {
    for (auto id : ids) {
        if (auto node = root->getChildByIDRecursive(id)) {
            if (auto button = typeinfo_cast<CCMenuItem*>(node)) {
                return button;
            }
        }
    }
    return nullptr;
}

void animateIntoPosition(CCNode* node, CCPoint endPosition, int delayIndex, bool animate) {
    if (!animate) {
        node->setPosition(endPosition);
        return;
    }
    node->setPosition(ccp(endPosition.x, endPosition.y - 28.f));
    node->setScale(.82f);
    float delay = .055f * delayIndex;
    node->runAction(CCSequence::create(
        CCDelayTime::create(delay),
        CCEaseBackOut::create(CCMoveTo::create(.48f, endPosition)),
        nullptr
    ));
    node->runAction(CCSequence::create(
        CCDelayTime::create(delay),
        CCEaseBackOut::create(CCScaleTo::create(.48f, 1.f)),
        nullptr
    ));
}

} // namespace

class $modify(NovaHomeMenu, MenuLayer) {
    // Tiles are real menu items. The original game button is kept on its
    // original menu (hidden), so custom hooks, sounds, and navigation remain.
    CCMenuItemSpriteExtra* createTile(
        CCMenuItem* original, char const* labelText, char const* spriteFrame,
        CCSize dimensions, bool hero, ccColor3B accent
    ) {
        auto visual = CCNode::create();
        visual->setContentSize(dimensions);
        visual->setAnchorPoint(ccp(.5f, .5f));
        visual->ignoreAnchorPointForPosition(false);

        const float w = dimensions.width;
        const float h = dimensions.height;
        auto painter = CCDrawNode::create();
        visual->addChild(painter);

        // Three alpha layers give a soft-glass look without an expensive blur pass.
        roundedRect(painter, 1.f, -3.f, w - 2.f, h, 16.f,
            rgba(4, 8, 21, .36f), rgba(10, 20, 40, 0.f));
        roundedRect(painter, 0.f, 0.f, w, h, 16.f,
            hero ? rgba(12, 35, 63, .90f) : rgba(15, 24, 47, .82f),
            accent4(accent, hero ? .82f : .48f));
        roundedRect(painter, 3.f, h - 17.f, w - 6.f, 13.f, 6.f,
            rgba(245, 254, 255, .10f), rgba(255, 255, 255, .0f));
        roundedRect(painter, 12.f, 10.f, w - 24.f, 2.5f, 1.f,
            accent4(accent, hero ? .56f : .28f), accent4(accent, 0.f));

        // Actual GD button art when available; a glyph fallback if a texture pack
        // removes or renames a sprite. All hit areas use the full rounded tile.
        auto cachedIconFrame = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(spriteFrame);
        if (cachedIconFrame) {
            auto icon = CCSprite::createWithSpriteFrame(cachedIconFrame);
            float maxW = w * (hero ? .61f : .45f);
            float maxH = h * (hero ? .49f : .46f);
            auto size = icon->getContentSize();
            if (size.width > 0.f && size.height > 0.f) {
                icon->setScale(std::min(maxW / size.width, maxH / size.height));
            }
            icon->setPosition(ccp(w * .5f, h * (hero ? .61f : .60f)));
            visual->addChild(icon, 2);
        } else {
            auto fallback = CCLabelBMFont::create(hero ? ">" : "+", "bigFont.fnt");
            if (fallback) {
                fallback->setColor(accent);
                fallback->setScale(hero ? .85f : .55f);
                fallback->setPosition(ccp(w * .5f, h * .59f));
                visual->addChild(fallback, 2);
            }
        }

        auto title = CCLabelBMFont::create(labelText, "bigFont.fnt");
        if (title) {
            title->setColor(ccc3(240, 250, 255));
            title->setScale(hero ? .43f : (h < 70.f ? .33f : .36f));
            title->setPosition(ccp(w * .5f, hero ? 27.f : (h < 70.f ? 15.f : 19.f)));
            visual->addChild(title, 3);
        }

        auto tile = CCMenuItemSpriteExtra::create(
            visual, this, menu_selector(NovaHomeMenu::onTilePressed)
        );
        tile->setUserObject(original); // retained by cocos2d
        tile->setID(std::string("nova-tile-") + labelText);
        return tile;
    }

    void onTilePressed(CCObject* sender) {
        auto tapped = typeinfo_cast<CCNode*>(sender);
        if (!tapped) return;
        auto original = typeinfo_cast<CCMenuItem*>(tapped->getUserObject());
        if (original) {
            // CCMenuItem::activate invokes the original registered callback.
            original->activate();
        }
    }

    bool init() {
        if (!MenuLayer::init()) return false;

        auto play = findOriginal(this, {"play-button"});
        auto creator = findOriginal(this, {"creator-button"});
        auto garage = findOriginal(this, {"garage-button"});
        if (!play || !creator || !garage) {
            log::warn("NOVA Home: core menu IDs not found; keeping original menu unchanged");
            return true;
        }

        auto settings = Mod::get();
        auto accent = settings->getSettingValue<ccColor3B>("accent");
        const bool animate = settings->getSettingValue<bool>("entrance-animation");
        const bool smallTiles = settings->getSettingValue<bool>("secondary-tiles");
        const bool glass = settings->getSettingValue<bool>("glass-panel");

        auto size = CCDirector::sharedDirector()->getWinSize();
        const float scale = std::min(1.f,
            std::min((size.width - 48.f) / 432.f, (size.height - 40.f) / 260.f));

        auto dashboard = CCMenu::create();
        dashboard->setID("nova-home-dashboard"_spr);
        dashboard->setPosition(ccp(size.width / 2.f, size.height / 2.f - 6.f * scale));
        dashboard->setScale(scale);
        this->addChild(dashboard, 100);

        if (glass) {
            auto panel = CCDrawNode::create();
            roundedRect(panel, -219.f, -109.f, 438.f, 211.f, 24.f,
                rgba(5, 11, 28, .30f), accent4(accent, .12f));
            dashboard->addChild(panel, -10);
        }

        auto heading = CCLabelBMFont::create("NOVA  /  HOME", "bigFont.fnt");
        if (heading) {
            heading->setColor(accent);
            heading->setScale(.32f);
            heading->setPosition(ccp(-157.f, 94.f));
            dashboard->addChild(heading, 1);
        }

        struct TileInfo {
            CCMenuItem* original;
            char const* title;
            char const* icon;
            CCSize dimensions;
            CCPoint position;
            bool hero;
        };
        const std::array<TileInfo, 3> primaries = {{
            {creator, "CREATE", "GJ_creatorBtn_001.png", CCSize(110.f, 106.f), ccp(-150.f, 17.f), false},
            {play, "PLAY", "GJ_playBtn_001.png", CCSize(152.f, 132.f), ccp(0.f, 17.f), true},
            {garage, "ICONS", "GJ_garageBtn_001.png", CCSize(110.f, 106.f), ccp(150.f, 17.f), false}
        }};
        int animationIndex = 0;
        for (auto const& info : primaries) {
            auto tile = createTile(info.original, info.title, info.icon,
                                   info.dimensions, info.hero, accent);
            dashboard->addChild(tile, 5);
            animateIntoPosition(tile, info.position, animationIndex++, animate);
            info.original->setVisible(false);
        }

        if (smallTiles) {
            // Different GD releases and node-ID providers may use different IDs.
            // Never create a fake shortcut: only use a real original button.
            struct FooterInfo { CCMenuItem* original; char const* name; char const* image; };
            std::array<FooterInfo, 3> footer = {{
                {findOriginal(this, {"settings-button", "options-button"}),
                    "SETTINGS", "GJ_optionsBtn_001.png"},
                {findOriginal(this, {"stats-button", "statistics-button"}),
                    "STATS", "GJ_statsBtn_001.png"},
                {findOriginal(this, {"achievements-button", "achievement-button"}),
                    "AWARDS", "GJ_achievementsBtn_001.png"}
            }};
            std::unordered_set<CCMenuItem*> seen;
            std::vector<FooterInfo> found;
            for (auto info : footer) {
                if (info.original && !seen.count(info.original)) {
                    seen.insert(info.original);
                    found.push_back(info);
                }
            }
            auto count = static_cast<float>(found.size());
            for (size_t i = 0; i < found.size(); ++i) {
                // A full-width clickable area for all the secondary actions.
                auto const& info = found[i];
                float x = (static_cast<float>(i) - (count - 1.f) / 2.f) * 118.f;
                auto tile = createTile(info.original, info.name, info.image,
                    CCSize(110.f, 54.f), false, accent);
                dashboard->addChild(tile, 5);
                animateIntoPosition(tile, ccp(x, -73.f), animationIndex++, animate);
                info.original->setVisible(false);
            }
        }

        if (settings->getSettingValue<bool>("reposition-title")) {
            if (auto logo = this->getChildByID("main-title")) {
                logo->setPosition(ccp(size.width / 2.f, size.height - 33.f));
                logo->setScale(logo->getScale() * .78f);
            }
        }
        log::info("NOVA Home loaded: three primary tiles plus available shortcuts");
        return true;
    }
};
